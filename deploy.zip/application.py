import pickle
from flask import Flask,request,jsonify,render_template
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

application=Flask(__name__)
app=application

 #import pickle files both

standard_scaler=pickle.load(open("models/scaler.pkl","rb"))
ridge_model=pickle.load(open("models/lasso.pkl","rb"))

@app.route("/")
def index():
    return render_template("index.html")

@app.route('/predictdata', methods=['GET', 'POST'])
def predict_datapoint():
    if request.method == 'POST':
        try:
            Temperature = float(request.form.get('Temperature'))
            RH = float(request.form.get('RH'))
            Ws = float(request.form.get('Ws'))
            Rain = float(request.form.get('Rain'))
            FFMC = float(request.form.get('FFMC'))
            DMC = float(request.form.get('DMC'))
            ISI = float(request.form.get('ISI'))
            Classes = float(request.form.get('Classes'))
            Region = float(request.form.get('Region'))

            new_data = standard_scaler.transform(
                [[Temperature, RH, Ws, Rain, FFMC, DMC, ISI, Classes, Region]]
            )

            result = ridge_model.predict(new_data)

            return render_template("home.html", results=round(float(result[0]), 2))


        except Exception as e:
            return f"BACKEND ERROR 👉 {e}"

    return render_template("home.html")




if __name__=="__main__":
    app.run(host="0.0.0.0",port=port)
# jsonify to return result in JSON ,render_template for finding the url of html file.
